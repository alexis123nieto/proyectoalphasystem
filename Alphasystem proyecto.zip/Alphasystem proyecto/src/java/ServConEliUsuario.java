/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DIN
 */
@WebServlet(urlPatterns = {"/ServConEliUsuario"})
public class ServConEliUsuario extends HttpServlet {
    
    ResultSet cdr=null;
    Statement sentenciaSQL=null;
    Conexion conecta=new Conexion();
    
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        conecta.Conectar();
        sentenciaSQL=conecta.getSentenciaSQL();
    }
    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServConEliUsuario</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ServConEliUsuario at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String strComando = "SELECT * FROM usuarios";
            cdr = sentenciaSQL.executeQuery(strComando);
            out.println("<html><head><title>Eliminar</title></head>");
            out.println("<body> Consulta matricula de alumno");
            out.println("<form action=\"http://localhost:8084/VinosLicores_1.0/ServElimiUsuarios\" method=\"GET\">");
            out.println("<table border=\"1\"");
            out.println("<tr>");
            out.println("<th colspan=\"1\"><image src=\"image/descarga.png\"></th>\n" +
                    "<th colspan=\"3\"> Universidad Tecnologica De Tecamac</th>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>LIBROS</td>\n" +
                        "<td>PRÉSTAMO</td>\n" +
                        "<td>USUARIOS</td>");
             out.println("</tr>");
              out.println("<tr>");
               out.println("<td colspan=\"3\" rowspan=\"1\" style=\"height: 100px\"><center>ELIMINACIÓN DE AlUMNOS</center><br/><br/>");
               out.println("Captura la matricula <select name=\"matricula\"><br/></br>");
               out.println("<option>Opciones</option>");
               
               while(cdr.next()){
                   out.println("<option>" + cdr.getString("matricula") + "</option>");
               }
               
               out.println("</select></br></br>");
               out.println("<input type=\"submit\" value=\"Eliminar\">");
               out.println("</td>");
            out.println("</table>");
            out.println("</body></html>");
            
        } catch (Exception e) {
        }
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
