/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Angel
 */
import java.sql.*;
public class Conexion {
        private Connection conexion=null;
        private Statement sentenciaSQL = null;
        
        public void Conectar(){
            try {
                String controlador="com.mysql.jdbc.Driver";
                Class.forName(controlador).newInstance();
                
                   // conexion=DriverManager.getConnection("jdbc:mysql://am1shyeyqbxzy8gc.cbetxkdyhwsb.us-east-1.rds.amazonaws.com:3306/zxl4lpl8325rqc9l","j2qv3f0n8u3tzlnr","qzy4hgt7qyb5ljip");
               conexion=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/panaderia", "root", "");
                sentenciaSQL = getConexion().createStatement();
            } catch (ClassNotFoundException e) {
                System.out.println("No se pudo cargar el controlador: " + e.getMessage());
            }
            catch(SQLException e){
                System.out.println("Escepción SQL: " + e.getMessage());
            }
            catch(InstantiationException e){
                System.out.println("Objeto no creado. " + e.getMessage());
            }
            catch(IllegalAccessException e){
                System.out.println("Acceso Ilegal. " + e.getMessage());
            }
        }
        
        public void cerrar(){
            try {
                if(getSentenciaSQL() != null)
                    getSentenciaSQL().close();
                    if(getConexion() !=null) getConexion().close();
            } catch (SQLException ignorada) {}
        }

    public Connection getConexion() {
        return conexion;
    }

    public Statement getSentenciaSQL() {
        return sentenciaSQL;
    }
}
